/* <template>
    	<nav class="navbar navbar-expand-lg navbar-dark bg-dark mt-0">
		<!-- Navbar content -->
		<a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link mt-1" href="/">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link mt-1" href="/petitions">Petitions</a>
	  </li>
	</ul>
    
    <form class="login-buttons my-2 my-lg-0">
    <div v-if="this.loggedIn === false">
	  <a class="btn btn-outline-success my-2 my-sm-0 mr-2" type="button" href="/users/login">Login</a>
	  <a class="btn btn-outline-success my-2 my-smo-0" type="button" href="/users/register">Register</a>
    </div>
    <div v-else>
         <a class="btn btn-outline-success my-2 my-sm-0 mr-2" type="button" href="/users/logout">Logout</a>

    </div>

    </form>
  </div>
	  </nav>
</template>

<script>
export default {
}
</script> */