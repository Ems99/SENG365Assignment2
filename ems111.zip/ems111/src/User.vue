<template>
<div class="container">

     <router-link :to="{ name: 'viewuser' }">View my Profile</router-link>
   

</div>
    
</template>